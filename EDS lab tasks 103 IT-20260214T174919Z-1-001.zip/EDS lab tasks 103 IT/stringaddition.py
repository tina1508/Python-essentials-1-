s1 = input("Enter first string: ")
s2 = input("Enter second string: ")
print(s1 + s2)

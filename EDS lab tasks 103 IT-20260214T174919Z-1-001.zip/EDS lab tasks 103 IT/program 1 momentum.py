mass = float(input("Enter mass (kg): "))
velocity = float(input("Enter velocity (m/s): "))
momentum = mass * velocity
print("Momentum =", momentum, "kg·m/s")
